<?php
    require_once('controller.php');
    if(isset($_SESSION['id'])){
        //get user detail
        $usr_id = $_SESSION['id'];
        $getusers = mysqli_query($conn,"SELECT * FROM users WHERE id = '$usr_id' ");
        $gus = mysqli_fetch_array($getusers);

        //get inter view 
        $getinterview = mysqli_query($conn,"SELECT * FROM interview WHERE usr_id = '$usr_id' ");
        $gt = mysqli_fetch_array($getinterview);
    }else{
        header("location:sign-in");
    }
?>
<!DOCTYPE html>
 
<html lang="en" class="light">
    <!-- BEGIN: Head -->
    <head>
        <meta charset="utf-8">
        <link href="nobg.png" rel="shortcut icon">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Tinker admin is super flexible, powerful, clean & modern responsive tailwind admin template with unlimited possibilities.">
        <meta name="keywords" content="admin template, Tinker Admin Template, dashboard template, flat admin template, responsive admin template, web app">
        <meta name="author" content="LEFT4CODE">
        <title>Dashboard - Word Sanctuary Training</title>
        <!-- BEGIN: CSS Assets-->
        <link rel="stylesheet" href="dist/css/app.css" />
        <!-- END: CSS Assets-->
        <script src="sweetalert.min.js"></script>
        <script>
            function infoAlert(message){
            
            swal("Info!", message, "info");

            }

            function swiftsuccessAlert(message){
            
            swal("Hurray!", message, "success");

            }
            function errorAlert(message){
            swal("Something went wrong!", message, "error");
            }
        </script>
    </head>
    <!-- END: Head -->
    <body class="main">
        <!-- BEGIN: Mobile Menu -->
        <div class="mobile-menu mobile-menu--dashboard md:hidden">
            <div class="mobile-menu-bar">
                <a href="" class="flex mr-auto">
                    <img alt="Tinker Tailwind HTML Admin Template" class="w-8" src="image.png">
                </a>
                <a href="javascript:;" id="mobile-menu-toggler"> <i data-feather="bar-chart-2" class="w-8 h-8 text-gray-600 dark:text-white transform -rotate-90"></i> </a>
            </div>
            <ul class="mobile-menu-box py-5 hidden">
                <li>
                    <a href="dashboard" class="menu">
                    <div class="menu__icon"> <i data-feather="home"></i> </div>
                        <div class="menu__title"> Dashboard </div>
                    </a>
                </li>
                <li>
                    <a href="dashboard?pg=payment" class="menu">
                    <!-- <div class="menu__icon"> <i data-feather="home"></i> </div> -->
                        <div class="menu__title"> Payment </div>
                    </a>
                </li>
                <li>
                    <a href="dashboard?pg=interview" class="menu">
                    <!-- <div class="menu__icon"> <i data-feather="home"></i> </div> -->
                        <div class="menu__title"> Interview </div>
                    </a>
                </li>
                <li>
                    <a href="dashboard?pg=results" class="menu">
                    <!-- <div class="menu__icon"> <i data-feather="home"></i> </div> -->
                        <div class="menu__title"> Results </div>
                    </a>
                </li>
                 
                
            </ul>
        </div>
        <!-- END: Mobile Menu -->
        <div class="flex overflow-hidden">
            <!-- BEGIN: Side Menu -->
            <nav class="side-nav">
                <a href="" class="intro-x flex items-center pl-5 pt-4 mt-3">
                    <img alt="Tinker Tailwind HTML Admin Template" class="w-6" src="image.png">
                    <span class="hidden xl:block text-white text-lg ml-3"> Word Sanctuary<span class="font-medium"> Training</span> </span>
                </a>
                <div class="side-nav__devider my-6"></div>
                <ul>
                    <li>
                        <a href="dashboard" class="side-menu active">
                            <div class="side-menu__icon"> <i data-feather="home"></i> </div>
                            <div class="side-menu__title"> Dashboard </div>
                        </a>
                    </li>
                    <li>
                        <a href="dashboard?pg=payment" class="side-menu active">
                            <!-- <div class="side-menu__icon"> <i data-feather="home"></i> </div> -->
                            <div class="side-menu__title"> Payment </div>
                        </a>
                    </li>
                    <li>
                        <a href="dashboard?pg=interview" class="side-menu active">
                            <!-- <div class="side-menu__icon"> <i data-feather="home"></i> </div> -->
                            <div class="side-menu__title"> Interview</div>
                        </a>
                    </li>
                    <li>
                        <a href="dashboard?pg=result" class="side-menu active">
                            <!-- <div class="side-menu__icon"> <i data-feather="home"></i> </div> -->
                            <div class="side-menu__title"> Result</div>
                        </a>
                    </li>
  
                </ul>
            </nav>
            <!-- END: Side Menu -->
            <!-- BEGIN: Content -->
            <div class="content content--dashboard">
                <!-- BEGIN: Top Bar -->
                <div class="top-bar -mx-4 px-4 md:mx-0 md:px-0">
                    <!-- BEGIN: Breadcrumb -->
                    <div class="-intro-x breadcrumb mr-auto hidden sm:flex"> <a href="">Application</a> <i data-feather="chevron-right" class="breadcrumb__icon"></i> <a href="" class="breadcrumb--active">Dashboard</a> </div>
                    <!-- END: Breadcrumb -->
                    <!-- BEGIN: Search -->
              
                    <!-- END: Search -->
                    <!-- BEGIN: Notifications -->
                    <div class="intro-x dropdown mr-auto sm:mr-6">
                         
                      
                    </div>
                    <!-- END: Notifications -->
                    <!-- BEGIN: Account Menu -->
                    <div class="intro-x dropdown w-8 h-8">
                        <div class="dropdown-toggle w-8 h-8 rounded-full overflow-hidden shadow-lg image-fit zoom-in" role="button" aria-expanded="false">
                            <img alt="Tinker Tailwind HTML Admin Template" src="dist/images/profile-15.jpg">
                        </div>
                        <div class="dropdown-menu w-56">
                            <div class="dropdown-menu__content box dark:bg-dark-6">
                                <div class="p-4 border-b border-black border-opacity-5 dark:border-dark-3">
                                    <div class="font-medium">Brad Pitt</div>
                                    <div class="text-xs text-gray-600 mt-0.5 dark:text-gray-600">Frontend Engineer</div>
                                </div>
                                <div class="p-2">
                                    <a href="" class="flex items-center block p-2 transition duration-300 ease-in-out hover:bg-gray-200 dark:hover:bg-dark-3 rounded-md"> <i data-feather="user" class="w-4 h-4 mr-2"></i> Profile </a>
                                    <a href="" class="flex items-center block p-2 transition duration-300 ease-in-out hover:bg-gray-200 dark:hover:bg-dark-3 rounded-md"> <i data-feather="edit" class="w-4 h-4 mr-2"></i> Add Account </a>
                                    <a href="" class="flex items-center block p-2 transition duration-300 ease-in-out hover:bg-gray-200 dark:hover:bg-dark-3 rounded-md"> <i data-feather="lock" class="w-4 h-4 mr-2"></i> Reset Password </a>
                                    <a href="" class="flex items-center block p-2 transition duration-300 ease-in-out hover:bg-gray-200 dark:hover:bg-dark-3 rounded-md"> <i data-feather="help-circle" class="w-4 h-4 mr-2"></i> Help </a>
                                </div>
                                <div class="p-2 border-t border-black border-opacity-5 dark:border-dark-3">
                                    <a href="" class="flex items-center block p-2 transition duration-300 ease-in-out hover:bg-gray-200 dark:hover:bg-dark-3 rounded-md"> <i data-feather="toggle-right" class="w-4 h-4 mr-2"></i> Logout </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END: Account Menu -->
                </div>
                <!-- END: Top Bar -->
                <div class="relative">
                    <div class="grid grid-cols-12 gap-6">
                        <div class="col-span-12 xl:col-span-9 xxl:col-span-9 z-10">
                            <div class="mt-6 -mb-6 intro-y">
                                <?php 

                                    if(isset($_REQUEST['training-id'])){
                                        $tid = decrypt($_REQUEST['training-id']);
                                        $insert = mysqli_query($conn,"INSERT INTO interview (training_id,usr_id) VALUES ('$tid','$usr_id') ");
                                        if($insert){
                                            ?>
                                              <script>
                                                swiftsuccessAlert("You have enrolled for training, proceed to payment by click the button on this page");
                                              </script>          
                                              <a href="" > </a>  
                                            <?php
                                        }else{

                                        }
                                    }
                                
                                ?>
                            </div>
 
                        </div>
 
                    </div>
 
                </div>
                <div class="row">
                    <div class="card bg-light">
                        <div class="card-body text-white mt-4">
                            <?php 
                             
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END: Content -->
        </div>
        <!-- BEGIN: Dark Mode Switcher-->
        <div data-url="side-menu-dark-dashboard-overview-1.html" class="dark-mode-switcher cursor-pointer shadow-md fixed bottom-0 right-0 box dark:bg-dark-2 border rounded-full w-40 h-12 flex items-center justify-center z-50 mb-10 mr-10">
            <div class="mr-4 text-gray-700 dark:text-gray-300">Dark Mode</div>
            <div class="dark-mode-switcher__toggle border"></div>
        </div>
        <!-- END: Dark Mode Switcher-->
        <!-- BEGIN: JS Assets-->
        <script src="https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/markerclusterer.js"></script>
        <script src="https://maps.googleapis.com/maps/api/js?key=["your-google-map-api"]&libraries=places"></script>
        <script src="dist/js/app.js"></script>
        <!-- END: JS Assets-->
    </body>
</html>